import numpy as np
import warnings
import sys
from metrics import *
from Transformer4Ranking.model import *
from paddle.io import DataLoader
from dataloader import *
from args import config

vaild_annotate_dataset = TestDataset(config.valid_annotate_path, max_seq_len=config.max_seq_len, data_type='finetune')
# vaild_annotate_loader = DataLoader(vaild_annotate_dataset, batch_size=config.eval_batch_size) 

paddle.set_device("gpu:0")
id2doc=vaild_annotate_dataset.id2doc
bsz=config.eval_batch_size
loss_fn=nn.functional.margin_ranking_loss()

assert bsz>0 

model = TransformerModel(
    ntoken=config.ntokens, 
    hidden=config.emb_dim, 
    nhead=config.nhead, 
    nlayers=config.nlayers, 
    dropout=config.dropout,
    mode='finetune'
)

for doc_ids,docid_pairs in vaild_annotate_dataset:
    buffer=[]
    docs=[]
    batch_preds=[]
    doc_scores={}
    # print(doc_ids,docid_pairs) [[pos,neg],[pos,neg]] ==> [[pos,pos...pos],[neg,neg..neg]]
    assert id2doc
    for doc_id in doc_ids:
        if len(buffer)<bsz:
            buffer.append(id2doc[doc_id])
        else:
            buffer.append(id2doc[doc_id])

            input_feed=paddle.stack(buffer,) 
            '''
            collate input_feed  [(src_input, src_segment, src_padding_mask),(src_input, src_segment, src_padding_mask)] =>
            [[src_input],[src_segment],[src_padding_mask]]
            '''
            pred=model(**input_feed)
            batch_preds.append(pred)

            buffer=[]


    pred=model(buffer)
    print(pred)
    batch_preds.append(pred)

    scores=paddle.stack(x=batch_preds,axis=0)
    left_doc_ids,right_doc_ids=np.stack(docid_paris,axis=1)
    pos_doc_scores=paddle.to_tensor([doc_scores[id] for id in left_doc_ids])
    neg_doc_scores=paddle.to_tensor([doc_scores[id] for id in right_doc_ids])
    for i,doc_id in enumberate(doc_ids):
        doc_scores[doc_id]=scores[i]


    label=paddle.full_like(scores,1)
    loss= loss_fn(input=pos_doc_scores,others=neg_doc_scores,label=label)

    optimizer.step()
    scheduler.step()

